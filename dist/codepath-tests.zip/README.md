# 循码 Codepath

面向零基础学习者的中文实践课堂。17 个阶段、129 个小节、14 个综合项目，包含两套独立毕业验收：接管自己的 AI 辅助项目，以及分析和修改陌生 GitHub 项目。

## 开始学习

直接打开发布的网站，从 Python 第一课开始。右侧填写代码，点击“运行并检查”。按课程顺序完成讲解、练习与复盘，再进入实战项目。

- 44 个 Python 练习和 7 个 SQL 练习使用真实 Pyodide / SQLite 在浏览器中运行。第一次运行需要联网下载环境。
- 62 个本机指导小节涵盖开发工具、Java、FastAPI、Spring Boot、Spring AI、源码阅读和复杂项目工程。网页提供步骤与知识检查，不代替本机编译或项目验收。
- Agent 与多角色基础练习明确使用确定性模拟；真实模型集成在本机项目阶段进行。网站本身没有接入聊天模型；审核中心可运行单文件 JS/TS/Python 与业务断言、提示部分静态风险，不会自动审查整个任意仓库。
- 课程、草稿、笔记、项目检查与毕业自评保存在当前浏览器。用页面底部的“备份学习进度”导出，再在其他浏览器导入。
- 两套毕业验收要求真实代码、运行与测试证据。网站只能检查填写完整度，自评分不是第三方能力认证。

## 本地运行

这是普通静态网站，无需 npm 安装或构建。进入 `dist` 目录后，用一个本地 HTTP 服务打开。例如已经安装 Python 的 Windows 电脑：

```powershell
cd dist
py -m http.server 4317 --bind 127.0.0.1
```

然后打开 http://127.0.0.1:4317 。直接双击 HTML 可能受到浏览器 Worker 的文件来源限制，因此代码运行需要 HTTP / HTTPS。

## 文件结构

- `dist/index.html`：网站入口。
- `dist/style.css`：桌面与手机布局。
- `dist/curriculum.js`、`foundations.js`、`backend.js`、`ai-lessons.js`、`mastery.js`：逐课内容。
- `dist/projects.js`：原有十个项目的步骤、参考代码与验收标准。
- `dist/app.js`：路由、编辑、反馈、进度与备份。
- `dist/runner.js`：隔离在 Web Worker 中的 Python / SQL 运行环境。
- `dist/capstones.js`：毕业证据、自评分与记录导出。

## 内容边界

课程提供从入门到独立实践的训练路线，不承诺仅凭阅读或打卡就精通全部技术。复杂项目中的陌生库需要继续查阅对应版本的官方资料、运行最小实验并补充测试。

Spring 与模型提供方配置会随版本改变；课程包含官方入口，安装时应核对生成器和文档版本。学习参考代码不是已经具备鉴权、限流、生产监控等全部能力的商业系统。

内容核对日期：2026-09-22。

## v2 新增内容

- JavaScript 12 节、TypeScript 8 节、Linux 10 节、智能体系统 12 节。JS 9 节和 TS 7 节在浏览器真实运行，其他小节为本机实践。
- 智能体专项包含架构、状态、消息、去重、拓扑、任务竞价、DAG、BFS、Q 值更新、投票与失败评估。
- 首页每日挑战：14 题轮换，每个本地日期通过一次奖励 40 XP；每节首次完成 20 XP。XP 不认证能力，也不提供服务端反作弊。
- 审核中心分开显示静态提示、运行/断言结果、人工可行性与安全证据。规则有误报漏报；当前测试没有执行 Java 或部署 Linux。
- 学习代码在无同源权限的 iframe + Worker 中执行；运行最长 5 秒、加载最长 90 秒。Python/SQLite 依赖指定 CDN。
- 导出有完整文本预览和复制回退，适用于下载被浏览器抑制的情况。
- 每课增加独立解释、重做、调试、迁移自查；新增前端、Linux、协作协议、网站测试四个项目。

## 实际测试与复现

```
node --test tests/regression.cjs
python tests/exercises.py
python tests/runtime-python.py
python scripts/build-test-bundle.py
```

最后一个命令重建网站内可下载的测试包，排除 zip 本身。Node 60 项通过；Python/SQLite 51 个参考解通过，真实浏览器 worker 内嵌 Python 程序再验证 51 个参考解和 7 个反例。浏览器检查、FastAPI 测试和局限见 dist/test-report.html。

新增文件：new-courses.js / new-projects.js 为课程项目；learning-core.js 管理纯业务逻辑；daily.js 为题库；learning-hub.js 为首页、挑战和审核；sandbox.js 与 js-runner.js 为隔离执行；export-dialog.js 为导出；tests 与 scripts 保存可复现测试。
