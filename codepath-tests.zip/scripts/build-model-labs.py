from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
root=Path(__file__).resolve().parents[1]
with ZipFile(root/'dist/model-labs.zip','w',ZIP_DEFLATED) as z:
    for f in sorted((root/'labs').glob('*')):
        if f.is_file() and f.suffix in ('.py','.md'):
            z.write(f,f.relative_to(root))
with ZipFile(root/'dist/model-labs.zip') as z:
    assert z.testzip() is None
    assert len(z.namelist())==5
print('Validated model-labs.zip: 4 scripts and step-by-step README')
